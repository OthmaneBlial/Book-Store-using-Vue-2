<template>
  <div>

  <br><br>
    <div>
      <form  v-on:submit.prevent="searchBooks">
          <div>
            <input
              id = "search"
              placeholder="Search books"
              v-model="query"
            ></input>
          <button class="btn btn-primary btn-search" type="submit">Search</button>
        </div>
      </form>
    </div>
      <br><br>


<!--       <div class="row" v-if="allGifs">
        <div class="col-md-4 gif-image" v-for="gif in gifs">
          <img :src="gif" @click="showOneGif(gif)" style="width:700px;height:300px;">
        </div>
      </div>
      <div class="row"  v-if="oneGif">
        <button class="btn btn-warning" style="margin: 5px; " v-on:click="returnToAllGifs">Return to all Gifs</button>
        <div class="col-md-12">
          <img :src="chosenGif" alt="HTML5 Icon" style="width:1700px;height:800px;">
        </div>
      </div>
    </div> -->



<div class="container">
  <div class="row">
    <div class="col-md-4" v-for="book in books">
      <h4>{{ book.volumeInfo.title }}</h4>
      <img :src="book.volumeInfo.imageLinks.thumbnail" style="height:300px; width:200px;">
    </div>
  </div>
</div>

  </div>
</template>

<script>

  export default {
    /**
     * The name of the application.
     */
    name: 'GifApp',

    data() {
      return {
        books: [],
        book: {
          id: '',
          authors: [],
          title: '',
          description: '',
          publisher: '',
          language: '',
          thumbnail: '',
          pageCount: ''
        },
        query: "football"
      };
    },

    /**
     * The methods of this Vue instance.
     */
    methods: {

      searchBooks() {

        this.books = [];
        this.fetchBooks(this.query);

      },

      fetchBooks(query) {
        this.axios.get("https://www.googleapis.com/books/v1/volumes?q=" + query)
          .then(({data}) => {
            //this.gifs = data.data[0].images.downsized.url;
            //console.log(data.items[0]);

            /*this.book.id = data.items[0].id;
            this.book.authors = data.items[0].volumeInfo.authors;
            this.book.title = data.items[0].volumeInfo.title;
            this.book.description = data.items[0].volumeInfo.description;
            this.book.publisher = data.items[0].volumeInfo.publisher;
            this.book.language = data.items[0].volumeInfo.language;
            this.book.thumbnail = data.items[0].volumeInfo.imageLinks.thumbnail;
            this.book.pageCount = data.items[0].volumeInfo.pageCount;*/



            const obj = data.items;

            for ( const key in obj ) {

              this.books.push(obj[key]);
            }

          });


      },


    },
  }
</script>


<style>

#search {
  width: 1330px;
  height: 40px;
  padding: 5px;
  margin: 3px;
  margin-left: 1%;
  margin-right: 1%;
  font-size: 20px;
}

.btn-search {
  margin-top: 10px;
  width: 50%;
  margin-left: 25%;
  height: 50px;
  font-size: 20px;

}

.gif-image {
  
  padding: 10px;
}

</style>
